!pip install googlemaps #주피터 노트북에서 돌아가도록 작성
!pip install folium
!pip install seaborn

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from pandas import Series, DataFrame
import platform

data1=pd.read_excel('C:\\Users\\uj\\Desktop\\term_project\\범죄발생지_1990.xlsx')
#열명을 도시이름으로 변경
new_header = data1.iloc[0]
data1 = data1[1:]
data1.columns = new_header

data2=pd.read_excel('C:\\Users\\uj\\Desktop\\term_project\\범죄발생지_2011.xlsx')

#열명을 도시이름으로 변경(index하는 부분이 달라서 각각 구함)
data2_1=data2.iloc[:,0:10]
new_header = data2_1.iloc[0]
data2_1.columns=new_header
data2_1=data2_1[2:]

data2_2=data2.iloc[:,10:]
new_header = data2_2.iloc[1]
data2_2.columns=new_header
data2_2=data2_2[2:]


data2=pd.concat([data2_1,data2_2],axis=1)

data3=pd.read_excel('C:\\Users\\uj\\Desktop\\term_project\\범죄발생지_2017.xlsx')
data3_1=data3.iloc[:,0:11]
new_header = data3_1.iloc[0]
data3_1.columns=new_header
data3_1=data3_1[2:]

data3_2=data3.iloc[:,11:]
new_header = data3_2.iloc[1]
data3_2.columns=new_header
data3_2=data3_2[2:]

data3=pd.concat([data3_1,data3_2],axis=1)

#non값을 공백으로 변경하기
data1=data1.fillna('')
data2=data2.fillna('')
data3=data3.fillna('')

violent_crime_1990=data1.loc[0:27]
normal_crime_1990=data1.loc[28:]

violent_crime_2011=data2.loc[2:8]
normal_crime_2011=data2.loc[10:18]

violent_crime_2017=data3.loc[2:11]
normal_crime_2017=data3.loc[13:21]

#가정1
table_90=violent_crime_1990.iloc[0:,5:32]
ntable_90=normal_crime_1990.iloc[0:,5:32]

#가정2
table_11=data2.iloc[[1,8],3:56] 
table_17=data3.iloc[[1,11],3:88]

data4=pd.read_excel('C:\\Users\\uj\\Desktop\\term_project\\범죄시간_2017.xlsx')
data5=pd.read_excel('C:\\Users\\uj\\Desktop\\term_project\\범죄발생요일_2017.xlsx')

#죄종별(1)과 죄종별(2)를 합치기위해 죄종별2의 소계값에 죄종별(1)의 죄종명을 합쳐줌
index=0 
for i in data4['죄종별(2)']:
    if i=="소계":
        data4.iloc[index,1]=(data4.iloc[index,0]+"("+i+")")
        index+=1
    else:
        index+=1
#nan값을 공백으로 변경
data4=data4.fillna('')

#계산을 위해 data4를 slicing한 data4_slice만듬
data4_slice=data4.iloc[1:,3:11]
for n in range(1,44):
    data4_slice.loc[n]=(data4_slice.loc[n]/(data4.iloc[n,2]-data4.iloc[n,11]))*100
    #백분율 구함
time_percent=pd.concat([data4.iloc[0:1,3:11],data4_slice])
new_header = time_percent.iloc[0]
time_percent.columns=new_header#열명을 다시 설정
time_percent=pd.concat([data4['죄종별(2)'],time_percent],axis=1)
time_percent=time_percent.loc[1:]
time_percent = time_percent.rename(columns = {'죄종별(2)': '죄명'})

new_header = data5.iloc[0]
data5.columns=new_header
data5=data5.iloc[1:]

index=0 
for i in data5['죄종별(2)']:
    if i=="소계":
        data5.iloc[index,1]=(data5.iloc[index,0]+"("+i+")")
        index+=1
    else:
        index+=1

data5=data5.fillna('')

data5_slice=data5.iloc[:,2:]
for n in range(1,44):
    data5_slice.loc[n] =(data5_slice.loc[n]/(data5.iloc[n-1,2]))*100

vcrime_sort_90=table_90.apply(np.argsort,axis=1)#행방향으로 정렬
ranked_cols=table_90.columns.to_series()[vcrime_sort_90.values[:,::-1]]#내림차순으로 변경

ranked_90=[]
for i in ranked_cols: #1-3순위까지의 자료를 얻기위해 num으로 제한해줌    
    rank=[]
    num=0
    for n in i:
        rank.append(n)
        num+=1
        if(num>=3):
            break
    ranked_90.append(rank)
    
table_90[['1순위', '2순위', '3순위']]=pd.DataFrame(ranked_90, index=table_90.index)#table_90에 1-3순위 열추가후 값 입력
pd.concat([violent_crime_1990[["죄종별(4)"]],table_90[["1순위","2순위","3순위"]]],axis=1)#죄종별 순위를 보여주기 위해 만듬

#같은 방식으로 만들어줌
ncrime_sort_90=ntable_90.apply(np.argsort,axis=1)
nranked_cols=ntable_90.columns.to_series()[ncrime_sort_90.values[:,::-1]]


nranked_90=[]
for i in nranked_cols:
    rank=[]
    num=0
    for n in i:
        rank.append(n)
        num+=1
        if(num>=3):
            break
    nranked_90.append(rank)
ntable_90[['1순위', '2순위', '3순위']]=pd.DataFrame(nranked_90, index=ntable_90.index)
pd.concat([normal_crime_1990[["죄종별(4)"]],ntable_90[["1순위","2순위","3순위"]]],axis=1)

#1990년도 자료에는 따로 강력범 소계와 폭력범 소계가 없으므로 sum()함수를 이용해 구해줌

table_90.loc["강력범_백분율"]=(table_90.sum()/data1.iloc[0:,5:32].sum())*100 #table_90에 새로운 행추가
vranked_90=table_90.sort_values(by="강력범_백분율",axis=1).iloc[27:28,24:27]

#sort_value를 통해 정렬하면 오름차순 정렬되고 이를 통해 마지막 3개만 추출하고 그 것을 vranked_90에 저장함

vranked_90
#위와 같은 방식으로 구함

ntable_90.loc["폭력범_백분율"]=(ntable_90.sum()/data1.iloc[0:,5:32].sum())*100
nranked_90=ntable_90.sort_values(by="폭력범_백분율",axis=1).iloc[6:,24:27]
nranked_90

#2011년과 2017년 자료는 소계 자료가 포함돼 있으므로 그 값에 각각 접근함.
#같은방식으로 vranked_11과 nranked_11을 만듬


table_11.loc["강력범_백분율"]=(table_11.loc[3]/(table_11.loc[3]+table_11.loc[10]))*100
table_11.loc["폭력범_백분율"]=(table_11.loc[10]/(table_11.loc[3]+table_11.loc[10]))*100

vranked_11=table_11.sort_values(by="강력범_백분율",axis=1).iloc[2:3,50:]
nranked_11=table_11.sort_values(by="폭력범_백분율",axis=1).iloc[3:4,50:]

vranked_11
nranked_11

#위와 같은 방식으로 만듬

table_17.loc["강력범_백분율"]=(table_17.loc[3]/(table_17.loc[3]+table_17.loc[13]))*100
table_17.loc["폭력범_백분율"]=(table_17.loc[13]/(table_17.loc[3]+table_17.loc[13]))*100

vranked_17=table_17.sort_values(by="강력범_백분율",axis=1).iloc[2:3,82:]
nranked_17=table_17.sort_values(by="폭력범_백분율",axis=1).iloc[3:4,82:]

vranked_17
nranked_17

#각자료별로 순위를 입력받은 새로운 표를 만듬(all_년도 ->강력/ all_n_년도->폭력)

l1=[]
for a in range(27,0,-1):
    l1.append(a)
l1.extend([0,0,0])

all_90=table_90.sort_values(by="강력범_백분율",axis=1)
all_90.loc["강력범_순위"]=l1
all_n_90=ntable_90.sort_values(by="폭력범_백분율",axis=1)
all_n_90.loc["폭력범_순위"]=l1

l2=[]
for b in range(53,0,-1):
    l2.append(b)

all_11=table_11.sort_values(by="강력범_백분율",axis=1)    
all_11.loc["강력범_순위"]=l2
all_n_11=table_11.sort_values(by="폭력범_백분율",axis=1)   
all_n_11.loc["폭력범_순위"]=l2

l3=[]
for c in range(85,0,-1):
    l3.append(c)

all_17=table_17.sort_values(by="강력범_백분율",axis=1)    
all_17.loc["강력범_순위"]=l3
all_n_17=table_17.sort_values(by="폭력범_백분율",axis=1)   
all_n_17.loc["폭력범_순위"]=l3

data2_city=data2.iloc[:,3:56].columns
data3_city=data3.iloc[:,3:88].columns

cityname=[] #두 데이터가 모두 가지고 있는 도시명으로 통일하기위해서 cityname에 동일값을 저장함
for a in  data2_city:
    for b in data3_city:
        if(a==b):
            cityname.append(a)
cityname
#명시적으로 확인하기위해 새로운 dataframe인 df를 만듬.
data={'도시명':cityname}
df=DataFrame(data)

value1=all_11[cityname].loc['강력범_백분율']
value2=all_17[cityname].loc['강력범_백분율']
#각각의 년도별 자료로 부터 해당하는 도시명의 강력범_백분율 값을 가져와서 각각 value1, value2로 저장

df['범죄변화율']=list(value2-value1)#범죄변화율을 list형태로 변환하여 새로운 열을 만듬

import googlemaps
import folium
gmaps = googlemaps.Client(key="AIzaSyBGsnew9hpR2pg1W6Omf1ING_9JDLXx74o")
lat = [] #위도를 저장함
lng = [] #경도를 저장함

for name in cityname:
    tmpMap = gmaps.geocode(name)
    tmpLoc = tmpMap[0].get('geometry')
    lat.append(tmpLoc['location']['lat'])
    lng.append(tmpLoc['location']['lng'])
    
df['위도'] = lat
df['경도'] = lng 


map = folium.Map(location=[37.566535,126.977969], zoom_start=7)
#서울을 기준으로 잡음(location)
#zoom_start는 전국을 보기위해 작게 설정

for n in df.index:
    folium.CircleMarker([df['위도'][n], df['경도'][n]], radius=df['범죄변화율'][n]*10, 
                        color='#8E44AD', fill_color='#8E44AD').add_to(map)
    
map

import matplotlib.pyplot as plt
from pandas import DataFrame
import matplotlib as mpl
%matplotlib inline

#한글폰트설정
font_name = mpl.font_manager.FontProperties(fname='C:/Windows/Fonts/malgun.ttf').get_name()
mpl.rc('font', family=font_name)

#차트를 그리기 위해 행과 열을 바꿔줌

vranked_90=np.transpose(vranked_90)
vranked_11=np.transpose(vranked_11)
vranked_17=np.transpose(vranked_17)


nranked_90=np.transpose(nranked_90)
nranked_11=np.transpose(nranked_11)
nranked_17=np.transpose(nranked_17)

#년도별 1-3위(폭력범죄)
fig = plt.figure() 
fig, ax_lst = plt.subplots(1, 3, figsize=(8,5))  

ax_lst[0].plot(nranked_90,'ro-',color='yellowgreen')
ax_lst[1].plot(nranked_11,'ro-',color='pink')
ax_lst[2].plot(nranked_17,'ro-',color='purple')

plt.show()

fig = plt.figure()

#년도별 1-3위(강력범죄)
fig, ax_lst = plt.subplots(1, 3, figsize=(8,5))  

ax_lst[0].plot(vranked_90, 'ro-',color='yellowgreen')
ax_lst[1].plot(vranked_11, 'ro-',color='pink')
ax_lst[2].plot(vranked_17,'ro-',color='purple')

plt.show()

#2011년 폭력범 1위도시 여수시의 변화표
result1=pd.concat([table_11["여수시"].iloc[2:4],table_17["여수시"].iloc[2:4]],axis=1)
result1

#2011년 폭력범 2위도시 원주시의 변화표
result2=pd.concat([table_11["원주시"].iloc[2:4],table_17["원주시"].iloc[2:4]],axis=1)
result2

#2011년 폭력범 3위도시 광명시의 변화표
result3=pd.concat([table_11["광명시"].iloc[2:4],table_17["광명시"].iloc[2:4]],axis=1)
result3.rename(columns={result3.columns[0]:"광명시(2011)",result3.columns[1]:"광명시(2017)"})
result3

#2011년 강력범 1-3위의 강력범,폭력범 백분율이 2017년에 어떻게 변화했는지  

#2011년 강력범 1위도시 논산시의 변화표
result4=pd.concat([table_11["논산시"].iloc[2:4],table_17["논산시"].iloc[2:4]],axis=1)
result4

#2011년 강력범 2위도시 천안시의 변화표
result5=pd.concat([table_11["천안시"].iloc[2:4],table_17["천안시"].iloc[2:4]],axis=1)
result5

#2011년 강력범 3위도시 대전시의 변화표
result6=pd.concat([table_11["대전"].iloc[2:4],table_17["대전"].iloc[2:4]],axis=1)
result6

#각 열별 최대값을 구하기위해 첫번째 열을 없애고 열에 접근하기 쉽게 하기위해서 column명을 숫자로 바꿈
result_crime=[''] #죄명
cal=time_percent.iloc[:,1:]
column=1
new_header = [1,2,3,4,5,6,7,8]
cal.columns=new_header

for max in cal.max():
    row=1
    for value in cal[column]:
        if(max==value):
            result_crime.append(time_percent.loc[row,'죄명'])
            row+=1
        else:
            row+=1
    column+=1
    
time_percent.columns
data={'시간':time_percent.columns,'최대값':result_crime}
frame=DataFrame(data)
frame2=frame.loc[1:,:]
frame2=np.transpose(frame2)
new_header = frame2.iloc[0]
frame2.columns=new_header
frame2=frame2.iloc[1:]

columns=[]
num=0
for column in time_percent.columns:
    if(num!=0):
        columns.append(column)
        num+=1
    else:
        num+=1



rows=[]
num=0
for row in time_percent.loc[1]:
    if(num!=0):
        rows.append(row)
        num+=1
    else:
        num+=1
#색정하기
a, b, c = [plt.cm.Reds, plt.cm.Greens, plt.cm.Blues]


explode = (0, 0, 0, 0,0,0,0,0.2) 
colors=[a(0.8), a(0.7), a(0.6), a(0.5), a(0.4), a(0.3), a(0.2), a(0.1)] #색깔의 정도를 달리함



fig1, ax1 = plt.subplots()
ax1.pie(rows, explode=explode, labels=columns,colors=colors, autopct='%1.1f%%',shadow=True, startangle=90)
ax1.axis('equal')  
plt.title('시간대별 범죄율(전체)\n', fontsize=20)
plt.show()

rows2=[]
num=0
for row in time_percent.loc[2]:
    if(num!=0):
        rows2.append(row)
        num+=1
    else:
        num+=1

explode = (0, 0, 0, 0,0,0,0,0.2) 
colors=[b(0.8), b(0.7), b(0.6), b(0.5), b(0.4), b(0.3), b(0.2), b(0.1)]
fig2, ax2 = plt.subplots()
ax2.pie(rows2, explode=explode, labels=columns, autopct='%1.1f%%',colors=colors,shadow=True, startangle=90)

ax2.axis('equal')  
plt.title('시간대별 범죄율(강력)\n', fontsize=20)
plt.show()

rows3=[]
num=0
for row in time_percent.loc[12]:
    if(num!=0):
        rows3.append(row)
        num+=1
    else:
        num+=1

explode = (0, 0, 0, 0,0,0,0,0.2) 
colors=[c(0.8), c(0.7), c(0.6), c(0.5), c(0.4), c(0.3), c(0.2), c(0.1)]
fig3, ax3 = plt.subplots()
ax3.pie(rows3, explode=explode, labels=columns, autopct='%1.1f%%',colors=colors,shadow=True, startangle=90)

ax3.axis('equal')  
plt.title('시간대별 범죄율(폭력)\n', fontsize=20)
plt.show()

import seaborn as sns
data5_heatmap=data5_slice.iloc[:,1:]
data5_heatmap=np.transpose(data5_heatmap)
data5_heatmap.columns=data5["죄종별(2)"]
data5_heatmap=data5_heatmap.rename(columns={"죄종별(2)":'죄명'})
data5_heatmap=np.transpose(data5_heatmap)

plt.figure(figsize=(15, 10))
ax = sns.heatmap(data5_heatmap, annot=True, fmt="f")


